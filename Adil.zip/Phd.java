package lab09;
public class Phd extends Student {
    void takeExam(){
        System.out.println("PhdStudent takes exam by giving his final defense presentation.");
    }

}
