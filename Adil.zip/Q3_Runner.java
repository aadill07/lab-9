package lab09;
public class Q3_Runner {
    public static void main(String args[]) {
        Phd phd = new Phd();
        Graduate grad = new Graduate();
        phd.takeExam();
        grad.takeExam();
    }
}
