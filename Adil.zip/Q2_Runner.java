package lab09;
public class Q2_Runner {

    public static void main(String args[]) {
        CST tc = new CST("Call me at 3pm.");
        System.out.println(tc.countTokens());
    }
}
