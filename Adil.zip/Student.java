package lab09;
abstract class Student {

    abstract void takeExam();
    
}