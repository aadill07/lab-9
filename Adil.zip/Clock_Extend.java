package lab09;
public class Clock_Extend extends Clock {
    Clock_Extend(int a, int b, int c){
    super( a, b,  c);
    }
    public void Display(){
    super.Display();
    if(hour>=1 && hour<=12){
        hour=hour%12;
        System.out.println(+hour+" : "+minute+" : "+second+" AM\n");
    }
    else if(hour>=12 && hour<=24){
        hour=hour%12;
        System.out.println(+hour+" : "+minute+" : "+second+" PM\n");
    }
    
    
    }
}