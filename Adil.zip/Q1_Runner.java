
package lab09;

/**
 *
 * @author BOSS
 */
public class Q1_Runner {

    public static void main(String args[]) {
      Clock_Extend clockA = new Clock_Extend(12,32,32);
      Clock_Extend clockB = new Clock_Extend(3,12,23);
      clockA.Display();
      clockB.Display();
    }
}
