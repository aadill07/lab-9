package lab09;
public class Graduate extends Student {
   void takeExam(){
       System.out.println("The graduate student gives a written paper");
 
}
}
