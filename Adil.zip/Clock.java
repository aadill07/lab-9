package lab09;
public class Clock {
int hour;
int minute;
int second;

public Clock(){
this.hour=12;
this.minute=00;
this.second=00;
}

public Clock(int h, int m, int s){
this.hour=h;
this.minute=m;
this.second=s;
}
public void Display(){
    System.out.println(hour+":"+minute+":"+second);
}
    
}
